#!/bin/bash

passwd=$(cat hostkey)
echo $passwd
ip=172.16.99.1
IP=$(ifconfig | grep "Bcast" | awk -F: '{print $2}' | cut -d " " -f1)
source /etc/profile
source /etc/bashrc
expect -c "
    spawn rsync -r /mydata root@$ip:/backup/mysql_datadir/$IP
    expect {
        \"*(yes/no)?\" { send \"yes\r\" ; exp_continue}
        \"*password\" { send \"$passwd\r\" ; exp_continue }
}
" 

